//Homework2
//Group18_hw#2
//Eduardo Gomez, Elvis Velasquez
package com.example.homework2;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class Drink implements Parcelable {

    // Fields
    int alcoholContent;
    int drinkSizeOz;

    public Drink(int alcoholContent, int drinkSizeOz) {
        this.alcoholContent = alcoholContent;
        this.drinkSizeOz = drinkSizeOz;
    }

    protected Drink(Parcel in) {
        drinkSizeOz = in.readInt();
        alcoholContent = in.readInt();



    }

    public static final Creator<Drink> CREATOR = new Creator<Drink>() {
        @Override
        public Drink createFromParcel(Parcel in) {
            return new Drink(in);
        }

        @Override
        public Drink[] newArray(int size) {
            return new Drink[size];
        }
    };

    public int getAlcoholContent() {
        return alcoholContent;
    }

    public int getDrinkSizeOz() {
        return drinkSizeOz;
    }

    public void setAlcoholContent(int alcoholContent) {
        this.alcoholContent = alcoholContent;
    }

    public void setDrinkSizeOz(int drinkSizeOz) {
        this.drinkSizeOz = drinkSizeOz;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(drinkSizeOz);
        parcel.writeInt(alcoholContent);

    }
}
