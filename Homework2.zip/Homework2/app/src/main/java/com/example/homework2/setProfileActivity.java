//Homework2
//Group18_hw#2
//Eduardo Gomez, Elvis Velasquez
package com.example.homework2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class setProfileActivity extends AppCompatActivity {

    int weight = 0;
    String gender = "";
    public static final String KEY_Weight = "Weight";
    public static final String KEY_Weight_INT = "Weight_INT";
    public static final String KEY_GENDER = "GENDER";

    public void checkVaildNumber(EditText number){
        //check input to see if it is a valid number if not display toast
        try{
            weight = Integer.parseInt(number.getText().toString());
        }catch (Exception e){
            Toast.makeText(setProfileActivity.this, "Please enter a positive number", Toast.LENGTH_SHORT).show();
        }

        if(weight < 0){
            Toast.makeText(setProfileActivity.this, "Please enter a positive number", Toast.LENGTH_SHORT).show();
        }
    }

    //Checking that number and gender button have been chosen
    public boolean inputCheckerOne(Integer num, RadioGroup radio){
        if(num <= 0){
            Toast.makeText(setProfileActivity.this, "Please enter a positive number", Toast.LENGTH_SHORT).show();

            return false;
        }

        if(radio.getCheckedRadioButtonId() == -1){
            Toast.makeText(setProfileActivity.this, "Please select a gender", Toast.LENGTH_SHORT).show();
            return false;
        }else if(radio.getCheckedRadioButtonId() == R.id.radioButtonFemale){
            gender = "(Female)";

        }else if(radio.getCheckedRadioButtonId() == R.id.radioButtonMale){
            gender = "(Male)";
        }

        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_profile);

        //Buttons
        Button setButton = findViewById(R.id.weightButton);
        Button cancelButton = findViewById(R.id.buttonCancel);

        //text
        EditText weightEntered = findViewById(R.id.enterWeight);

        //radio groups and buttons
        RadioGroup genderButton = findViewById(R.id.radioGroupGender);
        RadioButton female = findViewById(R.id.radioButtonFemale);


        //weight button functionality500
        setButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkVaildNumber(weightEntered);

                if(inputCheckerOne(weight, genderButton)) {

                    String sendBack = String.format(String.valueOf(weight)) + " lbs " + gender;
                    //enteredTextView.setText(String.format(String.valueOf(weight)) + " lbs " + gender);
                    weightEntered.getText().clear();
                    female.setChecked(true);
                    Intent intent = new Intent();
                    intent.putExtra(KEY_Weight, sendBack);
                    intent.putExtra(KEY_GENDER, gender);
                    intent.putExtra(KEY_Weight_INT, String.valueOf(weight));
                    setResult(RESULT_OK, intent);

                    finish();



                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

    }
}