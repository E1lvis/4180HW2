//Homework2
//Group18_hw#2
//Eduardo Gomez, Elvis Velasquez

package com.example.homework2;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DecimalFormat;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Integer weight = 0;
    String gender = "";
    int numDrinks = 0;
    ArrayList<Drink> drinks = new ArrayList<>();
    Double currentBAC = 0.00;
    String df = new DecimalFormat("0.000").format(currentBAC);
    final static public String Drinks_Key = "Drinks";

    //calculating BAC
    public double calculateBAC(Integer w, ArrayList<Drink> drinks, String gender){
        Double A = 0.00;
        Double calculatedValue = 0.00;

        for(Drink currentDrink: drinks){

            A +=  (Double.valueOf(currentDrink.getDrinkSizeOz()) * Double.valueOf(currentDrink.getAlcoholContent()) / 100);
        }

        switch (gender){
            case "(Female)":
                calculatedValue = A*5.14 / (weight*.66);


                break;
            case "(Male)":
                calculatedValue = A*5.14 / (weight*.73);


                break;


        }

        return calculatedValue;

    }

    public void checkStatus(TextView status, Double bac){
        if(bac > 0.2){
            status.setText("Over the limit!");
            status.setBackgroundColor(Color.parseColor("#c90606"));
        }else if(bac <= 0.2 && bac >= 0.08){
            status.setText("Be careful");
            status.setBackgroundColor(Color.parseColor("#cf6215"));
        }
    }

    public void fullReset(TextView enteredTextView, EditText weightEntered, TextView drinkNumber, TextView bacLevelNumber, ArrayList<Drink> drinks, Button addDrink, TextView status, SeekBar bar,
                          RadioButton female, RadioButton ounce){
        enteredTextView.setText("N/A");
        weightEntered.getText().clear();
        drinkNumber.setText("0");
        bacLevelNumber.setText("0.000");
        drinks.clear();
        addDrink.setEnabled(true);
        status.setText("You're safe");
        status.setBackgroundColor(Color.parseColor("#4caf50"));
        bar.setProgress(12);
        female.setChecked(true);
        ounce.setChecked(true);
        weight = 0;
        currentBAC = 0.00;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Text
        TextView enteredTextView = findViewById(R.id.textViewWeightInput);
        TextView drinkNumber = findViewById(R.id.textViewDrinksNumber);
        TextView bacLevelNumber = findViewById(R.id.textViewBACLevelNumber);
        TextView status = findViewById(R.id.textViewStatusResult);


        //Buttons
        Button resetButton = findViewById(R.id.buttonReset);
        Button mainSetButton = findViewById(R.id.buttonMainSet);
        Button viewDrinks = findViewById(R.id.buttonViewDrinks);
        Button mainAddDrink = findViewById(R.id.buttonMainAddDrink);


        //view drinks and add drinks button start off disabled
        mainAddDrink.setEnabled(false);
        viewDrinks.setEnabled(false);


        //main set button result functionality
        ActivityResultLauncher<Intent> forResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                //set the 100 t varuable later
                if(result != null && result.getResultCode() == RESULT_OK){
                    if (result.getData() != null && result.getData().getStringExtra(setProfileActivity.KEY_Weight) != null){
                        //if result is valid, set up screen and enable buttons
                        enteredTextView.setText(result.getData().getStringExtra(setProfileActivity.KEY_Weight));
                        //we can bring it in as a strint then convert i
                        weight = Integer.parseInt(result.getData().getStringExtra(setProfileActivity.KEY_Weight_INT));
                        gender = result.getData().getStringExtra(setProfileActivity.KEY_GENDER);
                        drinks.clear();
                        drinkNumber.setText("0");
                        bacLevelNumber.setText("0.000");
                        mainAddDrink.setEnabled(true);
                        viewDrinks.setEnabled(true);
                    }
                }
            }
        });

        //seekBarPercentageView.setText(String.valueOf(bar.getProgress()) + "%");

        //Main screen set button functionality
        mainSetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, setProfileActivity.class);
                forResult.launch(intent);

            }
        });

        //view drinks button start for result set up
        ActivityResultLauncher<Intent> forResultViewDrinks = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {

            }
        });

        //view drinks button functionality
        viewDrinks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(drinks.isEmpty()){
                    Toast.makeText(MainActivity.this, "You have no drinks.", Toast.LENGTH_SHORT).show();

                }else{
                    Intent intent = new Intent(MainActivity.this, com.example.homework2.viewDrinks.class);
                    intent.putExtra(Drinks_Key, drinks);
                    forResultViewDrinks.launch(intent);
                }
            }
        });

        //addDrink class returns the drink and adds to it array
        ActivityResultLauncher<Intent> forResultAddDrink = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if(result != null && result.getResultCode() == RESULT_OK){
                    if (result.getData() != null && result.getData().getParcelableExtra(addDrink.KEY_Drink) != null){

                        //add drink to array and update drink amount and BAC

                        Drink drink = result.getData().getParcelableExtra(addDrink.KEY_Drink);
                        drinks.add(drink);
                        drinkNumber.setText(String.valueOf(drinks.size()));

                        currentBAC = calculateBAC(weight, drinks, gender);
                        df = new DecimalFormat("0.000").format(currentBAC);
                        //bacLevelNumber.setText(String.valueOf(currentBAC));
                        bacLevelNumber.setText(df);
                    }
                }
                if(currentBAC >= 0.25){
                    mainAddDrink.setEnabled(false);
                    Toast.makeText(MainActivity.this, "No more drinks for you.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        //main screen add drink button functionality
        mainAddDrink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, com.example.homework2.addDrink.class);
                forResultAddDrink.launch(intent);
            }
        });



        //I havent deleted this stuff just in case we need it
/*

        //weight button functionality500
        findViewById(R.id.weightButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkVaildNumber(weightEntered);

                if(inputCheckerOne(weight, genderButton)) {

                    enteredTextView.setText(String.format(String.valueOf(weight)) + " lbs " + gender);
                    weightEntered.getText().clear();


                    addDrink.setEnabled(true);
                    status.setText("You're safe");
                    status.setBackgroundColor(Color.parseColor("#4caf50"));
                    bar.setProgress(12);
                    female.setChecked(true);
                    ounce.setChecked(true);


                }

            }
        });

        //seekbar change changing the percent amount shown
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                seekBarPercentageView.setText(String.valueOf(i) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        //Add Drink button functionality
        //since the information has to be entered first, we can just check if wight has a string instead of running checkValidNumber
        addDrink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //check to make sure user has added needed info first
                //we can do this by checking if weight has info presented

                if(enteredTextView.getText().toString().matches("")){

                    Toast.makeText(MainActivity.this, "Please enter weight and gender first.", Toast.LENGTH_SHORT).show();
                }else{
                    // new drink
                    Drink drink = new Drink(0,0);  // doesnt have alcohol % or #Oz yet

                    // set drink size depending on which radio button was clicked
                    switch (drinkSizes.getCheckedRadioButtonId()){
                        case R.id.radioButtonOz:
                            drink.setDrinkSizeOz(1);
                            break;
                        case R.id.radioButtonFiveOunce:
                            drink.setDrinkSizeOz(5);
                            break;
                        case R.id.radioButtonTwelveOunce:
                            drink.setDrinkSizeOz(12);
                            break;
                    }

                    // set alcohol content
                    drink.setAlcoholContent(bar.getProgress());

                    // add to drinks arraylist
                    drinks.add(drink);

                    // display drink info to user
                    drinkNumber.setText(String.valueOf(drinks.size()));

                    //calculate BAC Level

                    RadioButton chosenGender = findViewById(genderButton.getCheckedRadioButtonId());
                    currentBAC = calculateBAC(weight, drinks, String.valueOf(chosenGender.getText()));

                }

                //calculate BAC and format the result
                df = new DecimalFormat("0.000").format(currentBAC);
                //bacLevelNumber.setText(String.valueOf(currentBAC));
                bacLevelNumber.setText(df);

                checkStatus(status, currentBAC);

                if(currentBAC >= 0.25){
                    addDrink.setEnabled(false);
                    Toast.makeText(MainActivity.this, "No more drinks for you.", Toast.LENGTH_SHORT).show();
                }

            }



        });

        //RESET BUTTON
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Reset screen and variables
                fullReset(enteredTextView, weightEntered, drinkNumber, bacLevelNumber, drinks, addDrink, status, bar, female, ounce);

            }
        });

 */
    }

}