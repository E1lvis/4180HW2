//Homework2
//Group18_hw#2
//Eduardo Gomez, Elvis Velasquez
package com.example.homework2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class addDrink extends AppCompatActivity {
    public static  final String KEY_Drink = "Drink";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_drink);

        //Buttons
        Button addDrink = findViewById((R.id.buttonAddDrink));

        //seekbar variables
        SeekBar bar = findViewById(R.id.seekBar);
        TextView seekBarPercentageView = findViewById((R.id.textSeekBarPercentage));

        //radio groups and buttons
        RadioGroup drinkSizes = findViewById(R.id.drinkSizes);

        //seekbar change changing the percent amount shown
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                seekBarPercentageView.setText(String.valueOf(i) + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        addDrink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // new drink
                Drink drink = new Drink(0,0);  // doesnt have alcohol % or #Oz yet

                // set drink size depending on which radio button was clicked
                switch (drinkSizes.getCheckedRadioButtonId()){
                    case R.id.radioButtonOz:
                        drink.setDrinkSizeOz(1);
                        break;
                    case R.id.radioButtonFiveOunce:
                        drink.setDrinkSizeOz(5);
                        break;
                    case R.id.radioButtonTwelveOunce:
                        drink.setDrinkSizeOz(12);
                        break;
                }

                // set alcohol content
                drink.setAlcoholContent(bar.getProgress());

                Intent intent = new Intent();
                intent.putExtra(KEY_Drink, drink);

                setResult(RESULT_OK, intent);

                finish();


            }
        });
    }
}